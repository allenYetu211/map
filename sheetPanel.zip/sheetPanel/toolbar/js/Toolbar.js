document.write('<link href="sheetPanel/toolbar/css/font-awesome.min.css" rel="stylesheet" media="screen">');
document.write('<link href="sheetPanel/toolbar/css/documentation.css" rel="stylesheet" >');
document.write('<link href="sheetPanel/toolbar/css/prettify.css" rel="stylesheet">');
document.write('<link href="sheetPanel/toolbar/css/jquery.toolbar.css" rel="stylesheet"/>');
document.write('<link href="sheetPanel/toolbar/css/Toolbar.css" rel="stylesheet"/>');

//document.write('<script src="sheetPanel/toolbar/js/jquery-1.11.0.min.js"></script>');
document.write('<script src="sheetPanel/toolbar/js/jquery.toolbar.min.js"></script>');