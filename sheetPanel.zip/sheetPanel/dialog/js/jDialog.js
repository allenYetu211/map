document.write('<link href="sheetPanel/dialog/css/jDialog.css" rel="stylesheet" type="text/css">');
//document.write('<script src="sheetPanel/dialog/js/jquery.js" type="text/javascript"></script>');
document.write('<script src="sheetPanel/dialog/js/jquery.drag.js" type="text/javascript"></script>');
document.write('<script src="sheetPanel/dialog/js/jquery.mask.js" type="text/javascript"></script>');
document.write('<script src="sheetPanel/dialog/js/jquery.dialog.js" type="text/javascript"></script>');